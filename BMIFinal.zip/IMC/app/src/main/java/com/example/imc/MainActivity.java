package com.example.imc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText weight ,height;
    TextView result;
    String calculation, BMIresult;
    Button calculate_button ;
    String msg;
NumberPicker p1;
    NumberPicker p2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       final NumberPicker  p1=findViewById(R.id.p1);
        p1.setMaxValue(200);
        p1.setMinValue(0);
        final NumberPicker  p2=findViewById(R.id.p2);
        p2.setMaxValue(200);
        p2.setMinValue(0);
        weight=findViewById(R.id.weight);
        height=findViewById(R.id.height);
        weight.setVisibility(View.INVISIBLE);
        height.setVisibility(View.INVISIBLE);


        result = findViewById(R.id.result);
        EditText edit1=findViewById(R.id.edit1);
        RadioButton femme=findViewById(R.id.women);
        RadioButton homme=findViewById(R.id.men);

        calculate_button = (Button) findViewById(R.id.Resbtn);

        p1.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                Integer a =newVal;
                p2.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
                    @Override
                    public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                        Integer b =newVal;



                        calculate_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myintent = new Intent(MainActivity.this,ActRes.class);
                String s1 = weight.getText().toString();
                String s2 = height.getText().toString();
              //  float weightValue = Float.parseFloat(s1);
               // float heightValue = Float.parseFloat(s2);
                Float weightValue = Float.parseFloat(String.valueOf(a));
                Float heightValue = Float.parseFloat(String.valueOf(b));
Float f= heightValue/100;

                float bmi= weightValue /(f*f) ;
                if (bmi <= 16) {
                    BMIresult="severly under weight";

                }
                else if (bmi>= 16 && bmi<=18.5)
                {
                    BMIresult="under weight";

                }
                else if (bmi>=18.5 && bmi<=24.9)
                {
                    BMIresult="normal weight";

                }
                else if (bmi>=25 && bmi<=29.9)
                {
                    BMIresult="overweight";

                }
                else
                {
                    BMIresult="obese";

                }
                calculation="Result:    "+bmi+""+BMIresult;
                result.setText(calculation);
                String s=edit1.getText().toString();

                if (femme.isChecked())
                    s= "Mlle"+" "+ s;

                else if (homme.isChecked())
                    s="Mr"+" "+s;



                myintent.putExtra("res", String.valueOf(calculation));
                myintent.putExtra("name",s);
                myintent.putExtra("bmi",String.valueOf(BMIresult));


                startActivity(myintent);
            }


            });     }
                });
            }
        });   };


    }

