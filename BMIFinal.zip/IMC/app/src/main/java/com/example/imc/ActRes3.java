package com.example.imc;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;



public class ActRes3 extends AppCompatActivity {
    TextView result;
    String bmi;
    ImageView a1,a2,a3,a4,a5;
Button again;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act_res3);
        ImageView a1 = (ImageView)findViewById(R.id.a1);
        a1.setVisibility(View.INVISIBLE);
        ImageView a2 = (ImageView)findViewById(R.id.a2);
        a2.setVisibility(View.INVISIBLE);
        ImageView a3 = (ImageView)findViewById(R.id.a3);
        a3.setVisibility(View.INVISIBLE);
        ImageView a4 = (ImageView)findViewById(R.id.a4);
        a4.setVisibility(View.INVISIBLE);
        ImageView a5 = (ImageView)findViewById(R.id.a5);
        a5.setVisibility(View.INVISIBLE);
        Button again=findViewById(R.id.again) ;


        TextView result = findViewById(R.id.result);


        String bmi = getIntent().getStringExtra("res");
        result.setText(bmi);

       String bb= bmi;


       // if (bb.equals("Mangez plus de calories que votre corps n’en brûle")) {

       //     a1.setVisibility(View.VISIBLE);


     //   }
    //    else if (bb.equals("Mangez cinq à six petits repas pendant la journée plutôt que deux ou trois gros repas")){
      //      a2.setVisibility(View.VISIBLE);

        //}
        //else if (bb.equals("bonne santé essayer de pratiquer le sport aussi")){
          //  a3.setVisibility(View.VISIBLE);

        //}
        //else if (bb.equals("Mangez plus de portions de légumes et de fruits")){
          //  a4.setVisibility(View.VISIBLE);

        //}
        //else if (bb.equals("Encouragez à manger lentement et seulement quand vous avez faim")){
          //  a5.setVisibility(View.VISIBLE);

        //}

        switch (bmi) {

            case"health care":


                a1.setVisibility(View.VISIBLE);
                result.setText("Mangez plus de calories que votre corps n’en brûle");
                break;


            case"advice2":
                a2.setVisibility(View.VISIBLE);
             //   result.setText(" Mangez cinq à six petits repas pendant la journée plutôt que deux ou trois gros repas");

                break;
            case"good health":
                a3.setVisibility(View.VISIBLE);


                break;
            case "practice sport":
                a4.setVisibility(View.VISIBLE);

                break;
            case "doctor needed":
                a5.setVisibility(View.VISIBLE);


                break;


            default:bmi="nope";
        }


again.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent i;
        i = new Intent(ActRes3.this,MainActivity.class);
        startActivity(i);
    }
});



    }
}